//
//  Subcategoria.m
//  Farmapedia
//
//  Created by Diego Murillo on 07/09/13.
//  Copyright (c) 2013 Diego Murillo. All rights reserved.
//

#import "Subcategoria.h"

@implementation Subcategoria

@end
