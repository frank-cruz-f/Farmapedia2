//
//  TableViewController.h
//  Farmapedia
//
//  Created by Diego Murillo on 01/09/13.
//  Copyright (c) 2013 Diego Murillo. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "ListaMedicamentosViewController.h"

@interface ListaMedicamentosViewController : UITableViewController

@property(strong,nonatomic) NSArray *listaMedicamentos;


@end
