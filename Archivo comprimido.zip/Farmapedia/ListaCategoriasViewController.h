//
//  ListaCategoriasViewController.h
//  Farmapedia
//
//  Created by Diego Murillo on 07/09/13.
//  Copyright (c) 2013 Diego Murillo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Categoria.h"

@interface ListaCategoriasViewController : UITableViewController

@property(strong, nonatomic) NSArray *listaCategorias;

@end
