//
//  AppDelegate.h
//  Farmapedia
//
//  Created by Diego Murillo on 01/09/13.
//  Copyright (c) 2013 Diego Murillo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
