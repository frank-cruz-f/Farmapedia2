//
//  ListaSubcategoriasViewController.h
//  Farmapedia
//
//  Created by Diego Murillo on 07/09/13.
//  Copyright (c) 2013 Diego Murillo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListaSubcategoriasViewController : UITableViewController

@property(strong, nonatomic) NSArray *listaSubcategorias;

@end
